function [result,nPeaks,thePeaks,I,Ism,dIdt,dIdtsm,pd,pdN,resultsFolderStr] = YXW_xtal_kinetics08(I,xt,dxt,resultsPath,theFileSpec, ...
                                                                            timeStep,pixSize,smoothWindows, ...
                                                                            doNormalize, ...
                                                                            findPeaksParms,doPlots)
% This function imports avi files and performs a pixel-by-pixel analysis of
% polarization intenisty time series. The avi file represents a time series
% of images.
% For each x,y position the I(t) curve is smoothed ('sgolay') prior to the
% derivative calculation. The dI/dt curve is also smoothed ('guassian'),
% and then the peaks if the dI/dt curve are loacted. Peak position in time
% and peak width are used to generate histograms. 
% Input paramaters:
%   thepn = the full pathname to the avi file of interest.
%   timeStep = the timestep for each frame in the avi file.
%   pixSize = pixel dimensions assuming square pixels.
%   smoothWindows = a 2-element array with the first element the window
%                   size for the data smoothing opeeration. and the second
%                   element is the window size for the dI/dthh
%                   smoothing operation.
%   findPeaksParms = an array with the parameters required for the
%                   findpeaks routine.
%                     [       SlopeThreshold = 0.007;
%                             AmpThreshold = 0.8;
%                             SmoothWidth = 9;
%                             FitWidth = 9;
%                             SmoothType = 3;
%                             PeakGroup = 2;e]
%
%   doPlots = set to TRUE to plot curves during processing
%
% The routine outputs the folowing:
% For each value in the spatial average field, a folder is created with the name in the form: Results_N_pix_date_time. For example: Results_1pix_20201009_150729
% i.	In this folder will be saved figures (the various plots generated during the processing) and three csv files.
% ii.	Peaks_date_time.csv: this file has a list of all peaks identified in the data set.
% iii.	Settings_date_time.csv: this file lists the settings used to process the video.
% iv.	Histogram_date_time.csv: This file has the data of all peak transition times in the default histogram format. This is the data that is in the histogram plots.


% Copyright (C) 2020, Will Heinz
% Optical Microscopy and Analysis Laboratory
% Cancer Research Technology Program
% Frederick National Laboratory for Cancer Research
% National Cancer Institute


%% display the filename of the file we're working on

%%start stopwatch
tic
                    
% From Tom OHaver website: https://terpconnect.umd.edu/~toh/spectrum/PeakFindingandMeasurement.htm#findpeaksx
%reasonable initial value for Gaussian peaks is 0.7*WidthPoints^-2, where WidthPoints is the number of data points in the half-width (FWHM) of the peak. 
% AmpThreshold - Discriminates on the basis of peak height. Any peaks with height less than this value are ignored.
% SmoothWidth - Width of the smooth function that is applied to data before the slope is measured. Larger values of SmoothWidth will neglect small, sharp features. A reasonable value is typically about equal to 1/2 of the number of data points in the half-width of the peaks.
% PeakGroup - The number of points around the "top part" of the (unsmoothed) peak that are taken to estimate the peak heights. If the value of PeakGroup is 1 or 2, the maximum y value of the 1 or 2 points at the point of zero-crossing is taken as the peak height value; if PeakGroup is n is 3 or greater, the average of the next n points is taken as the peak height value. For spikes or very narrow peaks, keep PeakGroup=1 or 2; for broad or noisy peaks, make PeakGroup larger to reduce the effect of noise. 
% Smoothtype determines the smoothing algorithm (see http://terpconnect.umd.edu/~toh/spectrum/Smoothing.html)
%     If smoothtype=1, rectangular (sliding-average or boxcar)
%     If smoothtype=2, triangular (2 passes of sliding-average)
%     If smoothtype=3, pseudo-Gaussian (3 passes of sliding-average)
% Basically, higher values yield  greater reduction in high-frequency noise, at the expense of slower execution. For a comparison of these smoothing types, see SmoothingComparison.html.

%% pull values out of the arguments
 %peak fitting params
     SlopeThreshold = findPeaksParms(1);
     AmpThreshold = findPeaksParms(2);
     SmoothWidth = findPeaksParms(3);
     FitWidth = findPeaksParms(4);
     SmoothType = findPeaksParms(5);
     PeakGroup = findPeaksParms(6);
     
% fonts and display parameters for the plots
theFontSize = 18; %this is for xylabels
theNumberFontSize = 12; %this is for the numbers on the axes

%   get the file name parts
[fpath,fname,fext] = fileparts(theFileSpec);


%%load the settings into a table for export later
settingsNames = [   "timeStep", ...
                    "pixSize", ...
                    "smoothWindowI", ...
                    "smoothWindowdIdt", ...
                    "SlopeThreshold", ...
                    "AmpThreeshold", ...
                    "SmoothWidth", ...
                    "FitWidth", ...
                    "SmoothType", ...
                    "PeakGroup"];
settingsVars =  [   timeStep, ...
                    pixSize, ...
                    smoothWindows(1), ...
                    smoothWindows(2), ...
                    SlopeThreshold, ...
                    AmpThreshold, ...
                    SmoothWidth, ...
                    FitWidth, ...
                    SmoothType, ...
                    PeakGroup];
            
                
%get dimensions if I
sizeI = size(I);
v.Height = sizeI(1);
v.Width = sizeI(2);
v.NumFrames = sizeI(3);

% Build arrays based on the dimensions of the frames and how many there are
    Ism = zeros(v.Height,v.Width,v.NumFrames);;    %the smoothed data
    dIdt = zeros(v.Height,v.Width,v.NumFrames);;   %dI/dt (of the smoothed data)
    dIdtsm = zeros(v.Height,v.Width,v.NumFrames);; %the smoothed dI/dt

%build results data structures
results = cell(v.Height,v.Width); %this will hold outputs of findpeaks routines
npeaks = zeros(v.Height,v.Width,v.NumFrames); %this is the number of peaks found at each pixel

% get date and time for results folder and filenames
theDateTime = datetime();
dateTimeStr = datestr(theDateTime,'_yyyymmdd_HHMMSS');

%% make a results folder in the same folder as the raw data
resultsFolderStr = strcat(resultsPath,dateTimeStr);
mkdir(fpath,resultsFolderStr);

%smooth the raw data
Ism = smoothdata(I,3,'sgolay',smoothWindows(1));

%% plot all I(t) at once
int_figure = figure('Color','w');
int_ax = axes(int_figure);
rIsm = reshape(Ism,v.Height*v.Width,v.NumFrames);
plot(int_ax,xt,rIsm);

title_Inorm = strcat("All I(t) vs t");
title(title_Inorm,'FontSize',theFontSize);

xlabel_y = xlabel("Time (s)",'FontSize',theFontSize);
ylabel_y = ylabel("I(t) (arb.)",'FontSize',theFontSize);

%% normalize the Ism curves to the average of the beginning and end
if (doNormalize == 'On')
    Ism = YXW_xtal_kinetics_normTrace(Ism,smoothWindows(3:4));
end

%% plot all normalized I(t) at once
norm_figure = figure('Color','w');
norm_ax = axes(norm_figure);
rInorm = reshape(Ism,v.Height*v.Width,v.NumFrames);
plot(norm_ax,xt,rInorm);

title_Inorm = strcat("All normalized I(t) vs t");
title(title_Inorm,'FontSize',theFontSize);

xlabel_ynorm = xlabel("Time (s)",'FontSize',theFontSize);
ylabel_ynorm = ylabel("I(t) (arb.)",'FontSize',theFontSize);

%% calculate dI/dt, invert it, and smooth it
dIdt = -diff(Ism,1,3)/timeStep;
dIdtsm = smoothdata(dIdt,3,'gaussian',smoothWindows(2));

%% plot all dI/dt at once
diff_figure = figure('Color','w');
diff_ax = axes(diff_figure);
rdIdtsm = reshape(dIdtsm,v.Height*v.Width,v.NumFrames-1);
plot(diff_ax,dxt,rdIdtsm);

title_dIdtsm = strcat("All dI/dt vs t");
title(title_dIdtsm,'FontSize',theFontSize);

xlabel_y = xlabel("Time (s)",'FontSize',theFontSize);
ylabel_y = ylabel("dI(t)/dt (arb.)",'FontSize',theFontSize);
           
%ask for a threshold using a dialog
% ampThreshDialogPrompt = 'Enter a threshold for peak amplitude';
% ampThreshDialogTitle = 'Threshold';
% ampThreshDialogDefInput = string(0.5 * max(rdIdtsm,[],'all'));
% ampThreDialogOpts.WindowStyle = 'Normal';
% AmpThreshold = inputdlg(ampThreshDialogPrompt, ...
%                         ampThreshDialogTitle, ...
%                         [1 35], ...
%                         ampThreshDialogDefInput, ...
%                         ampThreDialogOpts);
%                         
%AmpThreshold = str2num(  AmpThreshold{1});

AmpThreshold = input('Enter a threshold for peak amplitude:  ');

%update the settings for export
settingsVars(6) = AmpThreshold;

%% set up figures if doing plots
if doPlots
    %make a figure for plotting
    fy = figure('Name','Intensity v Time','Color','w');
    fdydt = figure('Name','dI/dt v Time','Color','w');
    
    midx = round(v.Width/2);
    midy = round(v.Height/2);
end

%% loop over all pixels and find the peaks in dI/dt
for y = 1:v.Height
    for x = 1:v.Width
        thisdIdtsm = squeeze(dIdtsm(y,x,:));
        
        %findpeaksXW on smooth derivative
        measuredPeaks = findpeaksxw(dxt,thisdIdtsm, ...
                                         SlopeThreshold, ...
                                         AmpThreshold, ...
                                         SmoothWidth, ...
                                         PeakGroup, ...
                                         SmoothType);
       sizeMeasuredPeaks = size(measuredPeaks);
       
       %store the results
        result{y,x} = measuredPeaks;
        nPeaks(y,x) = sizeMeasuredPeaks(1);
        
        %plot if asked to. As written this will plot only the trace of the
        %center pixel. Replace (x == midx) && (y == midy) with (x == y) to
        %plot traces for the diagonal pixels. This will take much longer to
        %run though.
        if (doPlots && (x == midx) && (y == midy));
            %grab the single traces
            thisI = squeeze(I(y,x,:));
            if (doNormalize == 'On')
                thisI = squeeze(YXW_xtal_kinetics_normTrace(thisI,smoothWindows(3:4)));
            end
            %thisInorm = squeeze(YXW_xtal_kinetics_normTrace(thisI,smoothWindows(3:4)));
            thisIsm = squeeze(Ism(y,x,:));
            thisdIdt = squeeze(dIdt(y,x,:));
            thisdIdtsm = thisdIdtsm;
            
            
           %plot I vs t (normed or not)
           figure(fy);
           clf(fy);
           plot(xt,thisI,'ro');
           title_y = strcat("I vs t at x = ",string(x),", y = ",string(y));
           title(title_y, 'FontSize',theFontSize);
           xlabel_y = xlabel("Time (s)",'FontSize',theFontSize);
           ylabel_y = ylabel("I(t) (arb.)",'FontSize',theFontSize);
           
           hold on;
            
            
           %plot smoothed y vs t
           plot(xt,thisIsm,'b-');
           
           %make a base filename including path
           base_fname = fullfile(fpath,resultsFolderStr,fname);
           
           %save this plot now & wherever! added 050520
           fy_nm = strcat(base_fname,"I vs t at x = ",string(x)," y = ",string(y));
           YXW_save_fig(fy,fy_nm)
           %save this plot now & wherever! added 050520
           
           %plot dydt vs y
           figure(fdydt);
           clf(fdydt);
           plot(dxt,thisdIdt,'ro');
           title_dydt = strcat("dI/dt vs t at x = ",string(x),", y = ",string(y));
           title(title_y, 'FontSize',theFontSize);
           xlabel_y = xlabel("Time (s)",'FontSize',theFontSize);
           ylabel_y = ylabel("dI(t)/dt (arb.)",'FontSize',theFontSize);
           
           title(title_dydt);
           hold on;
           
           %plot smothed dydt
           plot(dxt,thisdIdtsm,'b-');
           hold on
           
           %save this plot now & wherever!  added 050520
           fdydt_nm = strcat(base_fname,"dIdt vs t at x = ",string(x)," y = ",string(y));
           YXW_save_fig(fdydt,fdydt_nm)
           %save this plot now & wherever! added 050520
           
%            text(measuredPeaks(:,2),measuredPeaks(:,3), ...
%                 num2str(measuredPeaks(:,1)), ...
%                 'FontSize',18, ...
%                 'Color','red',...
%                 'HorizontalAlignment','center')  % Number the peaks found on the graph
        end
        
            
    end
end

%% output histogram

% load up the peaks for histograms
totalPeaks = sum(nPeaks,'all');
thePeaks = zeros(totalPeaks,6); % the columns of peaks are: x pixel, y pixel, peak number, peak position in time, peak height, peakwidth
peakIndex = 1;

% this loop loads thePeaks array with all the found peaks and their
% characteristics
for y = 1:v.Height
    for x = 1:v.Width
       %get the results for tha pixel
       measuredPeaks = result{y,x};
       sizeMeasuredPeaks = size(measuredPeaks);
       
       %add pixel info to the find peaks result
       measuredPeaks(:,5) = x;
       measuredPeaks(:,6) = y;
       
       %move x and y values to the first 2 columns of the array
       if (sizeMeasuredPeaks(1) == 1)
           measuredPeaks = circshift(measuredPeaks,2);
       else if (sizeMeasuredPeaks(1) > 1)
           measuredPeaks = circshift(measuredPeaks,2,2);
           end
       end
      
       %load the results into thePeaks array
       thePeaks(peakIndex:peakIndex+nPeaks(y,x)-1,:) = measuredPeaks;
      
       %update the peak index
       peakIndex = peakIndex + nPeaks(y,x);
    end
end



%% save all the settings in a csv file
settings_fn = fullfile(fpath,resultsFolderStr,strcat('Settings',dateTimeStr,'.csv')); 
sFileID = fopen(settings_fn,'w');
fprintf(sFileID,'%s,%s\n','Variable','Value');
fprintf(sFileID,'%s,%s\n','theFileSpec',theFileSpec);
for i = 1:length(settingsNames)
   fprintf(sFileID,'%s,%f\n',settingsNames(i),settingsVars(i)); 
end
fclose(sFileID);


%% save all peaks reesults as a csv file
thePeaksTable = array2table(thePeaks,'VariableNames',{  'X pixel', ...
                                                        'Y pixel', ...
                                                        'Peak Number', ...
                                                        'Peak Position', ...
                                                        'Peak Height', ...
                                                        'Peak Width' });
thePeaks_fn = fullfile(fpath,resultsFolderStr,strcat('Peaks',dateTimeStr,'.csv'));                                                      
writetable(thePeaksTable,thePeaks_fn);
%display(strcat('SAVED: ',thePeaks_fn));

%% save the plot of the intensity vs time
figure(fy)
intensity_fn = fullfile(fpath,resultsFolderStr,strcat('Intensity plot',dateTimeStr));
YXW_save_fig(fy,intensity_fn);

%% save the plot of the intensity vs time
figure(norm_figure)
norm_fn = fullfile(fpath,resultsFolderStr,strcat('Normalized Intensity overlay',dateTimeStr));
YXW_save_fig(norm_figure,norm_fn);


%% save the plot of the dI/dt
figure(fdydt)
dIdt_fn = fullfile(fpath,resultsFolderStr,strcat('Derivative plot',dateTimeStr));
YXW_save_fig(fdydt,dIdt_fn);

%% save the plot of all I(t)
figure(int_figure);
int_fn = fullfile(fpath,resultsFolderStr,strcat('Intensities overlay',dateTimeStr));
YXW_save_fig(int_figure,int_fn);

%% save the plot of all dI/dt
figure(diff_figure);
deriv_fn = fullfile(fpath,resultsFolderStr,strcat('Derivatives overlay',dateTimeStr));
YXW_save_fig(diff_figure,deriv_fn);

%% plot a histogram of all peak positions
hist_figure = figure('Color','w');
hist_axes = axes(hist_figure,'FontSize',theNumberFontSize);
[theCounts,theEdges,theBins] = histcounts(thePeaks(:,4), ...
                                'BinLimits',[dxt(1),dxt(end)], ...
                                'BinWidth', timeStep);
                            
the_hist = histogram('BinCounts',theCounts,'BinEdges',theEdges);
xlabel("Peak time (s)",'FontSize',theFontSize);
ylabel("Number of peaks",'FontSize',theFontSize);

%export the figure as a .fig file, a .tiff file, and export the raw data as
%a csv file.
hist_fn = fullfile(fpath,resultsFolderStr,strcat('Histogram',dateTimeStr));
YXW_save_fig(hist_figure,hist_fn);

%save the raw data as csv
hist_fn = fullfile(fpath,resultsFolderStr,strcat('Histogram',dateTimeStr,'.csv'));
histArray = [the_hist.BinEdges; [the_hist.BinCounts,nan]]'; %transpose the combined array
histTable = array2table(histArray,'VariableNames',{'Bin Edge','Bin Counts'});
writetable(histTable,hist_fn);
%display(strcat('SAVED: ',hist_fn));

%now we zoom in on a peak of interst to get a distribution of the widths
%associated with that peak
figure(hist_figure); % bring the figure to the front
input('Zoom in on Peak of Interest, then hit RETURN.'); %give instruction and wait for user to comply
xlim_hist = xlim(); %get the current x range of the figure

%get the widths corresponding to all these peaks
lowBin = max(find(theEdges <= xlim_hist(1)),[],'all'); %this is the lowest bin selected
highBin = min(find(theEdges >= xlim_hist(2)),[],'all') - 1; %this is the highest bin selected
peakWidthMask = (theBins >= lowBin) & (theBins <= highBin); %the mask based on the limits selected

%peakWidthMask = (theBins > xlim_hist(1)) & (theBins < xlim_hist(2)); %the mask based on the limits selected
peakWidths = thePeaks(peakWidthMask,6); %the list of peak widths

%display a histogram of these
h = histfit(peakWidths/2,ceil(sqrt(length(peakWidths))),'normal');
widthHist_figure = gcf();

% get the fitting params
pd = fitdist(peakWidths/2,'Normal');
pdN = length(peakWidths); %the number of peaks used
xlabel('HWHM (s)','FontSize',theFontSize);
ylabel('Counts','FontSize',theFontSize);
title({strjoin(['Peak time limits (max, min): (', strjoin(string(xlim),', '),')']),strjoin(['Gaussian fit: mu =', ...
                string(pd.mu),'  sigma =', string(pd.sigma)])},'FontSize',theNumberFontSize);
            
%display('Width histogram fit');
%display(pd);

%save the width histogram
widthHist_fn  = fullfile(fpath,resultsFolderStr,strcat('Width histogram',dateTimeStr));
YXW_save_fig(widthHist_figure,widthHist_fn);

%% calculate histograms of dIdtsm at each time point using the same limits
%and bin widths
nBins = 100;
theBinLimits = [-5,5];%[min(dIdtsm,[],'all'), max(dIdtsm,[],'all')];
theBinWidth = (theBinLimits(2) - theBinLimits(1))/nBins;
diff_hist2D = zeros(nBins,v.NumFrames-1);
for t = 1:v.NumFrames-1
    [thisHist, edges] = histcounts(dIdtsm(:,:,t),'BinLimits',theBinLimits,'BinWidth',theBinWidth);
    diff_hist2D(:,t) = thisHist;
end

%display it

histo_figure = figure('Color','w');
histo_ax = axes(histo_figure,'FontSize',theNumberFontSize);
imagesc(histo_ax,[dxt(1),dxt(end)],theBinLimits,diff_hist2D);
theColorbar = colorbar;
theColorbar.Label.String = 'Number of peaks';
xlabel('Time (s)','FontSize',theFontSize);
ylabel('dI/dt distribution','FontSize',theFontSize);

%export the figure as a .fig file, a .tiff file
histo_fn = fullfile(fpath,resultsFolderStr,strcat('Histogram v time',dateTimeStr));
YXW_save_fig(histo_figure,histo_fn);

%% plot the peak position vs width
scatter_figure = figure('Color','w');
scatter_ax = axes(scatter_figure,'FontSize',theNumberFontSize);
plot(scatter_ax,thePeaks(:,4),thePeaks(:,6)/2,'k.');

xlabel('Peak time (s)','FontSize',theFontSize);
ylabel('Peak half-width (s)','FontSize',theFontSize);
scatter_fn = fullfile(fpath,resultsFolderStr,strcat('Half width v time',dateTimeStr));
YXW_save_fig(scatter_figure,scatter_fn);

%% save the derivative of the smoothed data as an avi file
doDeriveMovie = lower(input('Write the derivative movie (Y/N)? ','s'));
%doDeriveMovie = 'n';%skip this automatically
if doDeriveMovie == 'y'
    
    % the limits for the dI/dt video
    file_suffix = '_diff.tif';
    dmax = 1.0; %0.6 * max(sdydt,[],'all');
    dmin = 0; %0.6 * min(sdydt,[],'all');

    videof = figure('Color','w');
    video_ax = axes(videof);
    colormap('jet');
    
    newFile = fullfile(fpath,resultsFolderStr,strcat(fname,dateTimeStr,'_diff.avi'));
    
    % make a 2-up version with the I(t) on the left, dI/dt on the right
    Imin = min(I,[],'all');
    Imax = max(I,[],'all');
    
    videof2 = figure('Color','w');
    video_ax2 = axes(videof2);
    colormap('gray');
    
    %this frame hold the combined frame for the actual video
    videof3 = figure();
    
%     
%     newFile2 = fullfile(fpath,resultsFolderStr,strcat(fname,dateTimeStr,'_diff2.avi'));
    
    %open video files for output
    v2 = VideoWriter(newFile); %the dI/dt alone
    open(v2);

%     v22 = VideoWriter(newFile2); % the 2-up version
%     open(v22);
    
    %getsome values for normalization
    topI = squeeze(I(:,:,1));% t=0 values
    bottomI = min(I,[],3); %min along time axis
    %topI = max(I,[],3); %max along time axis
    rangeI = topI - bottomI;
    Imin = 0.0;
    Imax = 1.0;
    
    for i = 1:v.NumFrames -1
             
        %the 2-up version
        figure(videof2);
        thisI = squeeze(I(:,:,i));
        thisI = (thisI - bottomI) ./ rangeI; %normalize the intensity 
        
        imagesc(flipud(thisI),[Imin,Imax]);
      %  title(strcat(sprintf('%0.1f',i*timeStep),' s'),'FontSize',theFontSize);
        axis image; %force the aspect ratio to equal that of the data
        axis xy; %put the origin at the bottom left.
        axis off; %turn off pixel labeling of axis. (Add a scale bar if needed later.)
        colormap('jet'); %use cold blue colormap.
        colorbar('southoutside');
        theFrameI = getframe(gcf);
        
        %the dI/dt video alone
        figure(videof);
        binaryImage = dIdtsm(:,:,i) >= (AmpThreshold);
        imagesc(video_ax,flipud(binaryImage),[dmin,dmax]);
        axis image; %force the aspect ratio to equal that of the data
        axis xy; %put the origin at the bottom left.
        axis off; %turn off pixel labeling of axis. (Add a scale bar if needed later.)
        
        colorbar('southoutside'); %add a color bar
       % title(strcat(sprintf('%0.1f',i*timeStep),' s'),'FontSize',theFontSize);
        theFramed = getframe(gcf);
        
               
        
        %convert the frames to iamges and concatenate them
        rgbI = frame2im(theFrameI);
        rgbd = frame2im(theFramed);
        theRGB = cat(2,rgbI,rgbd);
       
        
        
        %display the video in a new frame
        figure(videof3);
        imshow(theRGB);
        text(10,100,strcat(sprintf('%0.1f',i*timeStep),' s'),'FontSize',theFontSize);
        
        
        %get this frame and save it
        theFrame = getframe(gcf);
        writeVideo(v2,theFrame);
        
%         %the 2-up version
%         figure(videof2);
%         tiledlayout(1,2);
%         nexttile;
%         %the I(t) framme
%         thisI = squeeze(I(:,:,i));
%         imagesc(video_ax2,thisI,[dmin,dmax]);
%         title(strcat(string(i*timeStep),' s'),'FontSize',theFontSize);
%         
%         %the dI/dt frame
%         nexttile;
%         imagesc(video_ax2,binaryImage,[dmin,dmax]);
%         colorbar();
%         title(strcat(string(i*timeStep),' s'),'FontSize',theFontSize);
    end

    close(v2);
    close(videof);
end

doCloseFigures = lower(input('Close all figures (Y/N)? ','s'));

if doCloseFigures == 'y'

        close all;
end


%stop the stopwatch and report elapsed time
toc

end

%% save the figure as a .fig file and as a .tif file
function YXW_save_fig(theFigure,theFileName)
    %keep the background color the same as on the screen
    theFigure.InvertHardcopy = 'off';
    
    %make the filenames
    figFile = strcat(theFileName,'.fig');
    tifFile = strcat(theFileName,'.tif');
    
    %save ths fig file
    saveas(theFigure,figFile);
    %display(strcat('SAVED: ',figFile));
    
    %save ths tif file
    saveas(theFigure,tifFile);
    %display(strcat('SAVED: ',tifFile));
end
