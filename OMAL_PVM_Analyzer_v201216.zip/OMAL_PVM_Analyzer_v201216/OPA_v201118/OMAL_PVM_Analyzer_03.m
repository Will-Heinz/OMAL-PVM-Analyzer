% This software launches a graphical user interface to tools to analyze
% polarization video microscopy data.

% Copyright (C) 2020, Will Heinz
% Optical Microscopy and Analysis Laboratory
% Cancer Research Technology Program
% Frederick National Laboratory for Cancer Research
% National Cancer Institute

classdef OMAL_PVM_Analyzer_03 < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        OMALPVMAnalyzerUIFigure         matlab.ui.Figure
        FileMenu                        matlab.ui.container.Menu
        LoadMenu                        matlab.ui.container.Menu
        ExitMenu                        matlab.ui.container.Menu
        AnalysisMenu                    matlab.ui.container.Menu
        DoitMenu                        matlab.ui.container.Menu
        AboutMenu                       matlab.ui.container.Menu
        GridLayout                      matlab.ui.container.GridLayout
        LeftPanel                       matlab.ui.container.Panel
        LoadFileButton                  matlab.ui.control.Button
        FulllfilepathTextAreaLabel      matlab.ui.control.Label
        FulllfilepathTextArea           matlab.ui.control.TextArea
        TimestepsEditFieldLabel         matlab.ui.control.Label
        TimestepsEditField              matlab.ui.control.NumericEditField
        PixelsizemEditFieldLabel        matlab.ui.control.Label
        PixelsizemEditField             matlab.ui.control.NumericEditField
        FileselectionLabel              matlab.ui.control.Label
        ExitButton                      matlab.ui.control.Button
        CenterPanel                     matlab.ui.container.Panel
        SmoothingwindowsLabel           matlab.ui.control.Label
        ItwindowframesEditFieldLabel    matlab.ui.control.Label
        ItwindowframesEditField         matlab.ui.control.NumericEditField
        dIdtwindowframesEditFieldLabel  matlab.ui.control.Label
        dIdtwindowframesEditField       matlab.ui.control.NumericEditField
        SpatialbinningsizepixelsEditFieldLabel  matlab.ui.control.Label
        SpatialbinningsizepixelsEditField  matlab.ui.control.EditField
        NormalizetracesSwitchLabel      matlab.ui.control.Label
        NormalizetracesSwitch           matlab.ui.control.Switch
        NavgstartframesEditFieldLabel   matlab.ui.control.Label
        NavgstartframesEditField        matlab.ui.control.NumericEditField
        NavgendframesEditFieldLabel     matlab.ui.control.Label
        NavgendframesEditField          matlab.ui.control.NumericEditField
        RightPanel                      matlab.ui.container.Panel
        PeakfittingparamsLabel          matlab.ui.control.Label
        SlopethresholdEditFieldLabel    matlab.ui.control.Label
        SlopethresholdEditField         matlab.ui.control.NumericEditField
        AmplitudethresholdEditFieldLabel  matlab.ui.control.Label
        AmplitudethresholdEditField     matlab.ui.control.NumericEditField
        SmoothwidthframesEditFieldLabel  matlab.ui.control.Label
        SmoothwidthframesEditField      matlab.ui.control.NumericEditField
        FitwidthframesEditFieldLabel    matlab.ui.control.Label
        FitwidthframesEditField         matlab.ui.control.NumericEditField
        SmoothtypeEditFieldLabel        matlab.ui.control.Label
        SmoothtypeEditField             matlab.ui.control.NumericEditField
        PeakgroupEditFieldLabel         matlab.ui.control.Label
        PeakgroupEditField              matlab.ui.control.NumericEditField
        DoitButton                      matlab.ui.control.Button
    end

    % Properties that correspond to apps with auto-reflow
    properties (Access = private)
        onePanelWidth = 576;
        twoPanelWidth = 768;
    end

    
    properties (Access = private)
        theFileSpec % Full path specification to the file to analyze
        origPath = pwd %Get the current path, and go back there when done.
        thePath ='~/Documents/' % the path to the file (to be used in uigetfile as a default path).
        theVideo %the video object for the avi file.
        version = '2020-11-17' % Version
    end
    

    % Callbacks that handle component events
    methods (Access = private)

        % Code that executes after component creation
        function startupFcn(app)
            %update the app name in the window bar
            app.OMALPVMAnalyzerUIFigure.Name = strjoin({'OMAL PVM Analyzer -- ver.',app.version});
            
            %center the app in the screen
            movegui(app.OMALPVMAnalyzerUIFigure,'north');
        end

        % Button pushed function: LoadFileButton
        function LoadFileButtonPushed(app, event)
            %get a file
            [theFile, thePath] = uigetfile(fullfile(app.thePath,'*.avi'));
            
            %check that it is a file, assume it is an avi file
            if ~(theFile(1) ==0)
               %check that it is avi, if so keep it
                [qpath,qname,qext] = fileparts(theFile);
                if (qext == '.avi')
                
                    %store the file path and file as theFile Spec
                    app.theFileSpec = fullfile(thePath,theFile);
                
                    %update the text box with this value
                    app.FulllfilepathTextArea.Value =  app.theFileSpec;
                    
                    %get the video object
                    app.theVideo = VideoReader(app.theFileSpec);
                    
                    %update the spatial binning list
                    sepBlockList = omal_make_sepBlockList(app.theVideo.Height,app.theVideo.Width);
                    
                    %put all but the last value in the binning field
                    app.SpatialbinningsizepixelsEditField.Value = strjoin(string(sepBlockList(1:end-1)),',');
                end
                
            end
            
            
        end

        % Button pushed function: DoitButton
        function DoitButtonPushed(app, event)
            %This launches the analysis program with all the settings as parameters
            %First gather the settings and package them up nicely
  
            %smooth windows
            smoothWindows = [app.ItwindowframesEditField.Value, ...
                app.dIdtwindowframesEditField.Value, ...
                app.NavgstartframesEditField.Value, ...
                app.NavgendframesEditField.Value];
            
            %make the findpeaks paramters array based on the expected
            %format:
%              SlopeThreshold = findPeaksParms(1);%
%              AmpThreshold = findPeaksParms(2);%
%              SmoothWidth = findPeaksParms(3);%
%              FitWidth = findPeaksParms(4);%
%              SmoothType = findPeaksParms(5);%
%              PeakGroup = findPeaksParms(6);%
             
            findPeaksParms = [app.SlopethresholdEditField.Value, ...
                app.AmplitudethresholdEditField.Value, ...
                app.SmoothwidthframesEditField.Value, ...
                app.FitwidthframesEditField.Value, ...
                app.SmoothtypeEditField.Value, ...
                app.PeakgroupEditField.Value];
            
            %launch the analysis
            %YXW_xtal_kinetics_gui_wrapper(theFileSpec,timeStep,pixSize,blockDim,smoothWindows,findPeaksParms)
            result = YXW_xtal_kinetics_gui_wrapper(app.theFileSpec, ...
                app.TimestepsEditField.Value, ...
                app.PixelsizemEditField.Value, ...
                str2num(app.SpatialbinningsizepixelsEditField.Value), ...
                smoothWindows, ...
                string(app.NormalizetracesSwitch.Value), ...
                findPeaksParms);
            
           
        end

        % Button pushed function: ExitButton
        function ExitButtonPushed(app, event)
            delete(app);
        end

        % Menu selected function: LoadMenu
        function LoadMenuSelected(app, event)
            LoadFileButtonPushed(app, event)
        end

        % Menu selected function: ExitMenu
        function ExitMenuSelected(app, event)
            delete(app);
        end

        % Menu selected function: DoitMenu
        function DoitMenuSelected(app, event)
            DoitButtonPushed(app, event)
        end

        % Menu selected function: AboutMenu
        function AboutMenuSelected(app, event)
                %The about text
                aboutTxt{1} = ' ';
                aboutTxt{2} = 'OMAL_PVM_Analyzer';
                aboutTxt{3} = ' ';
                aboutTxt{4} = 'by Will Heinz';
                aboutTxt{5} = app.version;
                aboutTxt{6} = ' ';
                aboutTxt{7} = 'Optical Microscopy and Analysis Laboratory';
                aboutTxt{8} = 'Cancer Research Technology Program';
                aboutTxt{9} = 'Frederick National Laboratory for Cancer Research';
                aboutTxt{10} = 'National Cancer Institute';
                % 
                d = dialog('Position',[500 500 400 200],...
                            'Name','About OMAL PVM Analyzer');

                txt = uicontrol('Parent',d,...
                           'Position',[50 50 300 150], ...  
                           'Style','text',...
                           'FontSize',12,...
                           'String',aboutTxt);
% 
%                 btn = uicontrol('Parent',d,...
%                            'Position',[85 20 70 25],...
%                            'String','Close',...
%                            'Callback','delete(gcf)');
                       
                movegui(d,'north');
        end

        % Changes arrangement of the app based on UIFigure width
        function updateAppLayout(app, event)
            currentFigureWidth = app.OMALPVMAnalyzerUIFigure.Position(3);
            if(currentFigureWidth <= app.onePanelWidth)
                % Change to a 3x1 grid
                app.GridLayout.RowHeight = {408, 408, 408};
                app.GridLayout.ColumnWidth = {'1x'};
                app.CenterPanel.Layout.Row = 1;
                app.CenterPanel.Layout.Column = 1;
                app.LeftPanel.Layout.Row = 2;
                app.LeftPanel.Layout.Column = 1;
                app.RightPanel.Layout.Row = 3;
                app.RightPanel.Layout.Column = 1;
            elseif (currentFigureWidth > app.onePanelWidth && currentFigureWidth <= app.twoPanelWidth)
                % Change to a 2x2 grid
                app.GridLayout.RowHeight = {408, 408};
                app.GridLayout.ColumnWidth = {'1x', '1x'};
                app.CenterPanel.Layout.Row = 1;
                app.CenterPanel.Layout.Column = [1,2];
                app.LeftPanel.Layout.Row = 2;
                app.LeftPanel.Layout.Column = 1;
                app.RightPanel.Layout.Row = 2;
                app.RightPanel.Layout.Column = 2;
            else
                % Change to a 1x3 grid
                app.GridLayout.RowHeight = {'1x'};
                app.GridLayout.ColumnWidth = {279, '1x', 292};
                app.LeftPanel.Layout.Row = 1;
                app.LeftPanel.Layout.Column = 1;
                app.CenterPanel.Layout.Row = 1;
                app.CenterPanel.Layout.Column = 2;
                app.RightPanel.Layout.Row = 1;
                app.RightPanel.Layout.Column = 3;
            end
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create OMALPVMAnalyzerUIFigure and hide until all components are created
            app.OMALPVMAnalyzerUIFigure = uifigure('Visible', 'off');
            app.OMALPVMAnalyzerUIFigure.AutoResizeChildren = 'off';
            app.OMALPVMAnalyzerUIFigure.Position = [100 100 877 408];
            app.OMALPVMAnalyzerUIFigure.Name = 'OMAL PVM Analyzer';
            app.OMALPVMAnalyzerUIFigure.Resize = 'off';
            app.OMALPVMAnalyzerUIFigure.SizeChangedFcn = createCallbackFcn(app, @updateAppLayout, true);

            % Create FileMenu
            app.FileMenu = uimenu(app.OMALPVMAnalyzerUIFigure);
            app.FileMenu.Text = 'File';

            % Create LoadMenu
            app.LoadMenu = uimenu(app.FileMenu);
            app.LoadMenu.MenuSelectedFcn = createCallbackFcn(app, @LoadMenuSelected, true);
            app.LoadMenu.Text = 'Load';

            % Create ExitMenu
            app.ExitMenu = uimenu(app.FileMenu);
            app.ExitMenu.MenuSelectedFcn = createCallbackFcn(app, @ExitMenuSelected, true);
            app.ExitMenu.Text = 'Exit';

            % Create AnalysisMenu
            app.AnalysisMenu = uimenu(app.OMALPVMAnalyzerUIFigure);
            app.AnalysisMenu.Text = 'Analysis';

            % Create DoitMenu
            app.DoitMenu = uimenu(app.AnalysisMenu);
            app.DoitMenu.MenuSelectedFcn = createCallbackFcn(app, @DoitMenuSelected, true);
            app.DoitMenu.Text = 'Do it';

            % Create AboutMenu
            app.AboutMenu = uimenu(app.OMALPVMAnalyzerUIFigure);
            app.AboutMenu.MenuSelectedFcn = createCallbackFcn(app, @AboutMenuSelected, true);
            app.AboutMenu.Text = 'About';

            % Create GridLayout
            app.GridLayout = uigridlayout(app.OMALPVMAnalyzerUIFigure);
            app.GridLayout.ColumnWidth = {279, '1x', 292};
            app.GridLayout.RowHeight = {'1x'};
            app.GridLayout.ColumnSpacing = 0;
            app.GridLayout.RowSpacing = 0;
            app.GridLayout.Padding = [0 0 0 0];
            app.GridLayout.Scrollable = 'on';

            % Create LeftPanel
            app.LeftPanel = uipanel(app.GridLayout);
            app.LeftPanel.Layout.Row = 1;
            app.LeftPanel.Layout.Column = 1;

            % Create LoadFileButton
            app.LoadFileButton = uibutton(app.LeftPanel, 'push');
            app.LoadFileButton.ButtonPushedFcn = createCallbackFcn(app, @LoadFileButtonPushed, true);
            app.LoadFileButton.Tooltip = {'Click to load an avi file for analysis.'};
            app.LoadFileButton.Position = [12 337 100 22];
            app.LoadFileButton.Text = 'Load File';

            % Create FulllfilepathTextAreaLabel
            app.FulllfilepathTextAreaLabel = uilabel(app.LeftPanel);
            app.FulllfilepathTextAreaLabel.HorizontalAlignment = 'right';
            app.FulllfilepathTextAreaLabel.Position = [7 295 73 22];
            app.FulllfilepathTextAreaLabel.Text = 'Fulll file path';

            % Create FulllfilepathTextArea
            app.FulllfilepathTextArea = uitextarea(app.LeftPanel);
            app.FulllfilepathTextArea.Editable = 'off';
            app.FulllfilepathTextArea.Position = [88 225 186 92];

            % Create TimestepsEditFieldLabel
            app.TimestepsEditFieldLabel = uilabel(app.LeftPanel);
            app.TimestepsEditFieldLabel.HorizontalAlignment = 'right';
            app.TimestepsEditFieldLabel.Tooltip = {'Seconds/frame'};
            app.TimestepsEditFieldLabel.Position = [85 191 74 22];
            app.TimestepsEditFieldLabel.Text = 'Time step (s)';

            % Create TimestepsEditField
            app.TimestepsEditField = uieditfield(app.LeftPanel, 'numeric');
            app.TimestepsEditField.Position = [174 191 100 22];
            app.TimestepsEditField.Value = 1;

            % Create PixelsizemEditFieldLabel
            app.PixelsizemEditFieldLabel = uilabel(app.LeftPanel);
            app.PixelsizemEditFieldLabel.HorizontalAlignment = 'right';
            app.PixelsizemEditFieldLabel.Position = [77 164 82 22];
            app.PixelsizemEditFieldLabel.Text = 'Pixel size (�m)';

            % Create PixelsizemEditField
            app.PixelsizemEditField = uieditfield(app.LeftPanel, 'numeric');
            app.PixelsizemEditField.Tooltip = {'�m/pixel'};
            app.PixelsizemEditField.Position = [174 164 100 22];
            app.PixelsizemEditField.Value = 0.02475;

            % Create FileselectionLabel
            app.FileselectionLabel = uilabel(app.LeftPanel);
            app.FileselectionLabel.Position = [111 379 75 22];
            app.FileselectionLabel.Text = 'File selection';

            % Create ExitButton
            app.ExitButton = uibutton(app.LeftPanel, 'push');
            app.ExitButton.ButtonPushedFcn = createCallbackFcn(app, @ExitButtonPushed, true);
            app.ExitButton.Position = [12 27 100 22];
            app.ExitButton.Text = 'Exit';

            % Create CenterPanel
            app.CenterPanel = uipanel(app.GridLayout);
            app.CenterPanel.Layout.Row = 1;
            app.CenterPanel.Layout.Column = 2;

            % Create SmoothingwindowsLabel
            app.SmoothingwindowsLabel = uilabel(app.CenterPanel);
            app.SmoothingwindowsLabel.Position = [96 379 115 22];
            app.SmoothingwindowsLabel.Text = 'Smoothing windows';

            % Create ItwindowframesEditFieldLabel
            app.ItwindowframesEditFieldLabel = uilabel(app.CenterPanel);
            app.ItwindowframesEditFieldLabel.HorizontalAlignment = 'right';
            app.ItwindowframesEditFieldLabel.Position = [48 337 110 22];
            app.ItwindowframesEditFieldLabel.Text = 'I(t) window (frames)';

            % Create ItwindowframesEditField
            app.ItwindowframesEditField = uieditfield(app.CenterPanel, 'numeric');
            app.ItwindowframesEditField.Position = [173 337 100 22];
            app.ItwindowframesEditField.Value = 39;

            % Create dIdtwindowframesEditFieldLabel
            app.dIdtwindowframesEditFieldLabel = uilabel(app.CenterPanel);
            app.dIdtwindowframesEditFieldLabel.HorizontalAlignment = 'right';
            app.dIdtwindowframesEditFieldLabel.Position = [36 302 122 22];
            app.dIdtwindowframesEditFieldLabel.Text = 'dI/dt window (frames)';

            % Create dIdtwindowframesEditField
            app.dIdtwindowframesEditField = uieditfield(app.CenterPanel, 'numeric');
            app.dIdtwindowframesEditField.Position = [173 302 100 22];
            app.dIdtwindowframesEditField.Value = 15;

            % Create SpatialbinningsizepixelsEditFieldLabel
            app.SpatialbinningsizepixelsEditFieldLabel = uilabel(app.CenterPanel);
            app.SpatialbinningsizepixelsEditFieldLabel.HorizontalAlignment = 'right';
            app.SpatialbinningsizepixelsEditFieldLabel.Position = [8 260 150 22];
            app.SpatialbinningsizepixelsEditFieldLabel.Text = 'Spatial binning size (pixels)';

            % Create SpatialbinningsizepixelsEditField
            app.SpatialbinningsizepixelsEditField = uieditfield(app.CenterPanel, 'text');
            app.SpatialbinningsizepixelsEditField.HorizontalAlignment = 'right';
            app.SpatialbinningsizepixelsEditField.Tooltip = {'Array of neighborhood sizes to use to spatially average the raw data. For example, a  value of 3 will average a 3x3 pixel area.'};
            app.SpatialbinningsizepixelsEditField.Position = [173 260 100 22];
            app.SpatialbinningsizepixelsEditField.Value = '1,9';

            % Create NormalizetracesSwitchLabel
            app.NormalizetracesSwitchLabel = uilabel(app.CenterPanel);
            app.NormalizetracesSwitchLabel.HorizontalAlignment = 'center';
            app.NormalizetracesSwitchLabel.Position = [58 191 96 22];
            app.NormalizetracesSwitchLabel.Text = 'Normalize traces';

            % Create NormalizetracesSwitch
            app.NormalizetracesSwitch = uiswitch(app.CenterPanel, 'slider');
            app.NormalizetracesSwitch.Position = [211 194 40 17];

            % Create NavgstartframesEditFieldLabel
            app.NavgstartframesEditFieldLabel = uilabel(app.CenterPanel);
            app.NavgstartframesEditFieldLabel.HorizontalAlignment = 'right';
            app.NavgstartframesEditFieldLabel.Position = [51 153 107 22];
            app.NavgstartframesEditFieldLabel.Text = 'Navg start (frames)';

            % Create NavgstartframesEditField
            app.NavgstartframesEditField = uieditfield(app.CenterPanel, 'numeric');
            app.NavgstartframesEditField.Position = [173 153 100 22];
            app.NavgstartframesEditField.Value = 100;

            % Create NavgendframesEditFieldLabel
            app.NavgendframesEditFieldLabel = uilabel(app.CenterPanel);
            app.NavgendframesEditFieldLabel.HorizontalAlignment = 'right';
            app.NavgendframesEditFieldLabel.Position = [57 109 103 22];
            app.NavgendframesEditFieldLabel.Text = 'Navg end (frames)';

            % Create NavgendframesEditField
            app.NavgendframesEditField = uieditfield(app.CenterPanel, 'numeric');
            app.NavgendframesEditField.Position = [175 109 100 22];
            app.NavgendframesEditField.Value = 15;

            % Create RightPanel
            app.RightPanel = uipanel(app.GridLayout);
            app.RightPanel.Layout.Row = 1;
            app.RightPanel.Layout.Column = 3;

            % Create PeakfittingparamsLabel
            app.PeakfittingparamsLabel = uilabel(app.RightPanel);
            app.PeakfittingparamsLabel.Position = [102 379 109 22];
            app.PeakfittingparamsLabel.Text = 'Peak fitting params';

            % Create SlopethresholdEditFieldLabel
            app.SlopethresholdEditFieldLabel = uilabel(app.RightPanel);
            app.SlopethresholdEditFieldLabel.HorizontalAlignment = 'right';
            app.SlopethresholdEditFieldLabel.Position = [54 337 90 22];
            app.SlopethresholdEditFieldLabel.Text = 'Slope threshold';

            % Create SlopethresholdEditField
            app.SlopethresholdEditField = uieditfield(app.RightPanel, 'numeric');
            app.SlopethresholdEditField.Position = [159 337 100 22];
            app.SlopethresholdEditField.Value = 1e-05;

            % Create AmplitudethresholdEditFieldLabel
            app.AmplitudethresholdEditFieldLabel = uilabel(app.RightPanel);
            app.AmplitudethresholdEditFieldLabel.HorizontalAlignment = 'right';
            app.AmplitudethresholdEditFieldLabel.Position = [31 302 113 22];
            app.AmplitudethresholdEditFieldLabel.Text = 'Amplitude threshold';

            % Create AmplitudethresholdEditField
            app.AmplitudethresholdEditField = uieditfield(app.RightPanel, 'numeric');
            app.AmplitudethresholdEditField.Position = [159 302 100 22];
            app.AmplitudethresholdEditField.Value = 0.01;

            % Create SmoothwidthframesEditFieldLabel
            app.SmoothwidthframesEditFieldLabel = uilabel(app.RightPanel);
            app.SmoothwidthframesEditFieldLabel.HorizontalAlignment = 'right';
            app.SmoothwidthframesEditFieldLabel.Position = [20 260 127 22];
            app.SmoothwidthframesEditFieldLabel.Text = 'Smooth width (frames)';

            % Create SmoothwidthframesEditField
            app.SmoothwidthframesEditField = uieditfield(app.RightPanel, 'numeric');
            app.SmoothwidthframesEditField.Position = [159 260 100 22];
            app.SmoothwidthframesEditField.Value = 3;

            % Create FitwidthframesEditFieldLabel
            app.FitwidthframesEditFieldLabel = uilabel(app.RightPanel);
            app.FitwidthframesEditFieldLabel.HorizontalAlignment = 'right';
            app.FitwidthframesEditFieldLabel.Position = [46 218 98 22];
            app.FitwidthframesEditFieldLabel.Text = 'Fit width (frames)';

            % Create FitwidthframesEditField
            app.FitwidthframesEditField = uieditfield(app.RightPanel, 'numeric');
            app.FitwidthframesEditField.Position = [159 218 100 22];
            app.FitwidthframesEditField.Value = 9;

            % Create SmoothtypeEditFieldLabel
            app.SmoothtypeEditFieldLabel = uilabel(app.RightPanel);
            app.SmoothtypeEditFieldLabel.HorizontalAlignment = 'right';
            app.SmoothtypeEditFieldLabel.Position = [70 170 74 22];
            app.SmoothtypeEditFieldLabel.Text = 'Smooth type';

            % Create SmoothtypeEditField
            app.SmoothtypeEditField = uieditfield(app.RightPanel, 'numeric');
            app.SmoothtypeEditField.Position = [159 170 100 22];
            app.SmoothtypeEditField.Value = 1;

            % Create PeakgroupEditFieldLabel
            app.PeakgroupEditFieldLabel = uilabel(app.RightPanel);
            app.PeakgroupEditFieldLabel.HorizontalAlignment = 'right';
            app.PeakgroupEditFieldLabel.Position = [77 130 67 22];
            app.PeakgroupEditFieldLabel.Text = 'Peak group';

            % Create PeakgroupEditField
            app.PeakgroupEditField = uieditfield(app.RightPanel, 'numeric');
            app.PeakgroupEditField.Position = [159 130 100 22];
            app.PeakgroupEditField.Value = 2;

            % Create DoitButton
            app.DoitButton = uibutton(app.RightPanel, 'push');
            app.DoitButton.ButtonPushedFcn = createCallbackFcn(app, @DoitButtonPushed, true);
            app.DoitButton.Position = [159 27 100 22];
            app.DoitButton.Text = 'Do it';

            % Show the figure after all components are created
            app.OMALPVMAnalyzerUIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = OMAL_PVM_Analyzer_03

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.OMALPVMAnalyzerUIFigure)

            % Execute the startup function
            runStartupFcn(app, @startupFcn)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.OMALPVMAnalyzerUIFigure)
        end
    end
end