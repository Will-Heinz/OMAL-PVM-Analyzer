function result = YXW_xtal_kinetics_gui_wrapper(theFileSpec,timeStep,pixSize,blockDim,smoothWindows,doNormalize,findPeaksParms)
% This function processes a single data file using multiple xy pixel
% averages (1, 2x2, 3x3, 4x4, ...).
% The file name and all settings are passed from a gui.
% The routine calls the YXW_xtal_kinetics08.m routine which does the
% heavy lifting.
% That routine is a semiautomated analysis routine based on
% YXW_xtal_kinetics05.m, modified to work within this wrapper.
% It uses the blocksepfun routine to downsize the original data size.

    %% Set up and hard  wired values
    %the hardwired file spec
   % theFileSpec = '/Users/heinzwf/Documents/OMAL/Projects/Wang/Sam - Riboswitch Xtals/VM_Fig1_new/20200226 analysis/200305 Analysis Square xtal/Smooth area upper left/Substack (251-1541) smooth area upper left3.avi'
    %the maximum list of pixel neighborhood sizes to use in the average
    %blockDim = [1,5,9,10,15,30,60,90];%[1:180]; %for the Smooth upper left area
    
    %For the dark are in the center of the square xtal
    %theFileSpec = '/Users/heinzwf/Documents/OMAL/Projects/Wang/Sam - Riboswitch Xtals/VM_Fig1_new/20200226 analysis/200305 Analysis Square xtal/Dark area center/Substack (142-2311) Dark area center.avi'
    %the maximum list of pixel neighborhood sizes to use in the average
    %blockDim = [1,3,5,9,10,15,18,30,60,90];%[1:180]; %for the Dark area center
    
    %For the 10 mM photouncaged sample
    %theFileSpec = '/Users/heinzwf/Documents/OMAL/Projects/Wang/Sam - Riboswitch Xtals/VM_Fig1_new/20200226 analysis/200306 Analysis 10 mm ligand/Upper left/Sample 10 mM Upper Left Substack (20-450).avi'
    %the maximum list of pixel neighborhood sizes to use in the average
    %blockDim = [1,2,4,9,10,20,40];%[1:180]; %for the Dark area center
    
    %For the 1 uM photouncaged sample
    %theFileSpec = '/Users/heinzwf/Documents/OMAL/Projects/Wang/Sam - Riboswitch Xtals/VM_Fig1_new/20200226 analysis/200306 Analysis 1 uM ligand/Upper left/Sample 10 mM Upper Left Substack (20-450).avi'
    %the maximum list of pixel neighborhood sizes to use in the average
    %blockDim = [1,2,4,9,10,20,40];%[1:180]; %for the Dark area center
    
    %For the 1 uM photouncaged sample
   % theFileSpec = '/Users/heinzwf/Documents/OMAL/Projects/Wang/Sam - Riboswitch Xtals/VM_Fig1_new/200306 Fig1C Analysis/pcFig1c Substack (40-630)2.avi';
    %the maximum list of pixel neighborhood sizes to use in the average
    %blockDim = [1,3,4,9,18];%[1:180]; %for the Dark area center
    
    %For the 1 uM photouncaged sample
    %theFileSpec = '/Users/heinzwf/Documents/OMAL/Projects/Wang/Sam - Riboswitch Xtals/VM_Fig1_new/200306 Fig1C Analysis/pcFig1c Substack (40-630) Box1.avi';
    %the maximum list of pixel neighborhood sizes to use in the average
    %blockDim = [1,2,5,10,25];%[1:180]; %for the Dark area center
    
    %default result = 0, failure
    results = 0;
   
    %display update
    display(strjoin({'Working on:',theFileSpec}));
    
    %get the fiile parts
    [theFilePath,theFileName,theFileExt] = fileparts(theFileSpec);
  
    %the maximum list of pixel neighborhood sizes to use in the average
    %blockDim = [1,3,5,9,10,15,18,30,60,90];%[1:180]; %for the Smooth upper left area
    
    

     % ========== data scales ==================
    %timeStep = 0.3894; % should be (# of frames)/(time of experiment), Use 1 if unsure.
    %timeStep = 2.0851;% should be (# of frames)/(time of experiment), Use 1 if unsure.
    %timeStep = 0.634;% should be (# of frames)/(time of experiment), Use 1 if unsure.
    %timeStep = 0.2973;% should be (# of frames)/(time of experiment), Use 1 if unsure.
   
    %pixSize = 1;
     
    % ========   smooth windows for [ I(t), dI/dt, Npts for averaging start, end]   ==========
    %smoothWindows = [39, 15, 15];
     
    % =============== peak fitting params ===================
%      SlopeThreshold = 0.00001;
%      AmpThreshold = 0.01;
%      SmoothWidth = 3;
%      FitWidth = 9;
%      SmoothType = 1;
%      PeakGroup = 2;
     
     %put it all together
%     findPeaksParms = [SlopeThreshold, ...
%                         AmpThreshold, ...
%                         SmoothWidth, ...
%                         FitWidth, ...
%                         SmoothType, ...
%                        PeakGroup];
                    
   %doPlots flag
  doPlots = 1;

   
  %% Read the file
  [origI,Ism,dIdt,dIdtsm,xt,dxt,v] = YXW_xtal_kinetics_loadavi(theFileSpec,timeStep);
  %where I =  intensity array (MxNxT) M,N = height and width of frame and T is
%           the number of frames in the video.
%      Ism, dIdt,dIdtsm,xt,dxt are smoothed intensity, the derivative of
%      the intensity, the smoothed derivative of the intensity, time x axis
%      for intensity plots, and time x axis for derivative plots.
%   v = the videoReader object that has information about the file.

    %% Build the sepBlock size list
    %Use only neighborhoohs divisible into the image size
    sepBlockList = intersect(blockDim(rem(v.Height,blockDim) == 0),blockDim(rem(v.Width,blockDim) == 0));
    
    %the length of this list
    sepBlockListLength = length(sepBlockList);
    
    % make a results table for peak average peak widths and sigmas for each
    % nieghborhood size
    widthsResults = zeros(sepBlockListLength,4);
    
   %% Loop through the sepBlockList and analyze each averaged version of the data file
    for thisNeighborhood = 1:sepBlockListLength
        display(strcat('BlockDim = ',string(sepBlockList(thisNeighborhood))));
        
        %Average the intensity array every thisNeighborhood pixel square
        %per frame
        I = sepblockfun(origI,[sepBlockList(thisNeighborhood),sepBlockList(thisNeighborhood),1],'mean');
 
        %create a results path based on the neighborhood size and the
        %filename
        resultsPath = strcat('Results_',string(sepBlockList(thisNeighborhood)),'pix');
        
        %pass this to the analysis routine
        [result,nPeaks,thePeaks,I,Ism,dIdt,dIdtsm,pd,pdN,resultsFolderStr] = YXW_xtal_kinetics08(I,xt,dxt,resultsPath,theFileSpec, ...
                                                                            timeStep,pixSize,smoothWindows, ...
                                                                            doNormalize, ...
                                                                            findPeaksParms,...
                                                                            doPlots);
                                                                        
        %load up the width results arra                                                                
        widthsResults(thisNeighborhood,:) = [sepBlockList(thisNeighborhood),pd.mu,pd.sigma,pdN];
    end
    
    %%save the width results as a csv file
    wrTable = array2table(widthsResults,'VariableNames',{'Npix','Mean','Sigma','Npeaks'});
    widths_fn = fullfile(theFilePath,resultsFolderStr,strcat('Results_Width_v_N','.csv'));
    writetable(wrTable,widths_fn);
    
    %we're done!
    result = 1;
end