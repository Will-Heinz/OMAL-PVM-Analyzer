function Inorm = YXW_xtal_kinetics_normTrace(I,N)
%This function takes a I(y,x,t) traces and normalizes its range to [0,1] based
%on the average value of the first and last N elements.
%Inputs:    I = a #D array
%           N = number of elements to average [beginning, end]. IF N is a
%           scalar, it is coverted to a 1x2 array with equal values.

% Copyright (C) 2020, Will Heinz
% Optical Microscopy and Analysis Laboratory
% Cancer Research Technology Program
% Frederick National Laboratory for Cancer Research
% National Cancer Institute


%get the ziez of I
sizeI = size(I);

%create a results array
Inorm = zeros(sizeI);

%get the size of N and make it 1x2 if needed.
sizeN = length(N);
if (sizeN == 1)
    N(2) = N;
end

switch ndims(I)
    case 3
        %loop over each xy and normalize and store in Inorm
        for y = 1:sizeI(1)
            for x = 1:sizeI(2)
                %get the trace
                theTrace = I(y,x,:);
                 
                %calculate the normailized trace
                theNormTrace = omal_norm_trace(theTrace,N);

                %and store it in Inorm
                Inorm(y,x,:) = theNormTrace;
            end
        end
    case 2
        %process the single trace
        Inorm = omal_norm_trace(I,N);
        
    otherwise
        %punt
        Inorm = I;
end
end
