function sepBlockList = omal_make_sepBlockList(height,width)
    %This routine generates a set of numbers that divide evenly into height
    %and width. The source numbers are from an array defined by the smaller of height or width. The
    %results can be used in the sepBlockFun.
    %generate the array of possible
    
    
% Copyright (C) 2020, Will Heinz
% Optical Microscopy and Analysis Laboratory
% Cancer Research Technology Program
% Frederick National Laboratory for Cancer Research
% National Cancer Institute

   try
       [s,l] = bounds(height,width);
        blockDim = [1:s];
    
        %get the result
        sepBlockList= intersect(blockDim(rem(height,blockDim) == 0),blockDim(rem(width,blockDim) == 0));
   catch
       %if there is an error, return a value of 1
       sepBlockList = 1; 
   end
   
end