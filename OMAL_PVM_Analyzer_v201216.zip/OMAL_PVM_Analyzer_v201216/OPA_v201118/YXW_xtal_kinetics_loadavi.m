function [I,Ism,dIdt,dIdtsm,xt,dxt,v] = YXW_xtal_kinetics_loadavi(theFileSpec,timeStep)
%this function reads an avi file andd returns arrays of frames of the
%video and empty arrays for holding smoothed and derivative data.
%Required inputs:
%   theFileSpec = full path specification to the file to read
%   timeStep = time per frame
%the Result = [I,Ism,dIdt,didtsm,xt,dxt,v]
%where I =  intensity array (MxNxT) M,N = height and width of frame and T is
%           the number of frames in the video.
%      Ism, dIdt,dIdtsm,xt,dxt are smoothed intensity, the derivative of
%      the intensity, the smoothed derivative of the intensity, time x axis
%      for intensity plots, and time x axis for derivative plots.
%   v = the videoReader object that has information about the file.


%open the file as a video object
v = VideoReader(theFileSpec);

% Build arrays based on the dimensions of the frames and how many there are
    I = zeros(v.Height,v.Width,v.NumFrames); %the raw data
    Ism = I;    %the smoothed data
    dIdt = I;   %dI/dt (of the smoothed data)
    dIdtsm = I; %the smoothed dI/dt

%Build time axes  
%get an x-axis vector
xt = [0:v.NumFrames - 1] * timeStep; % time for raw data plots
dxt = xt(1:end-1); %time for derivative plots

%build results data structures
results = cell(v.Height,v.Width); %this will hold outputs of findpeaks routines
npeaks = zeros(v.Height,v.Width,v.NumFrames); %this is the number of peaks found at each pixel

%load up the raw data
for t = 1:v.NumFrames
    frame = readFrame(v);
    
    %convert to grey scale if an rgb image by averaging all 3 channels
    frameSize = size(frame); %get the size of the frame
    if ((length(frameSize) == 3) && (frameSize(3) == 3))
       frame = squeeze(mean(frame,3)); %average it
    end
    
    I(:,:,t) = frame; %load it into the stack
end

end