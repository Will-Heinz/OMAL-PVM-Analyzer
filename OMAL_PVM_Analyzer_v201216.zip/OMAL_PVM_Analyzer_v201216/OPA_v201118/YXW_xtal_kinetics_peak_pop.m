function [result mu N windows theFileSpec]  = YXW_xtal_kinetics_peak_pop(mu,N,windows, theFileSpec)
% This function reads in a results csv file generated from YXW_xtal_kinetics08.m
% and calculates the numbers of peaks within defined windows of a given
% transition.
% The function outputs a results file with window size, number of peaks,
% mean and sd of those peaks, and the percentage of .
%Inputs:    mu = the average peak position in time
%           N = the number of peaks found for this transistion
%           windows = and array of time windows to tally
%           C = an array of cluster centroids to be used as a start value.
%           theFileSpec = the full file spec to the csvfile with peak times

% Copyright (C) 2020, Will Heinz
% Optical Microscopy and Analysis Laboratory
% Cancer Research Technology Program
% Frederick National Laboratory for Cancer Research
% National Cancer Institute

%set default window sizes
winDefault = [1 2.19482675 3 4 5 7.5 10 15 20 25 30 40 50 60 70];

%set defaults a file spec if not passed
switch nargin
    case 0
        mu = 228.613775; % This is for the 1 pix results from: pix01 Peaks_20200309_131348.csv
        %the window size 2.19482675 is the SD of the mean from: pix01 Peaks_20200309_131348.csv
        %N = 32397; % This is for the 1 pix results from: pix01 Peaks_20200309_131348.csv 
        N=32400; %this is the number of pixels in a 180 x 180 ROI used in pix01 Peaks_20200309_131348.csv 
        windows = winDefault;
        theFileSpec = omal_uigetfile();
    case 1
        N = 324000;
        windows = winDefault;
        theFileSpec = omal_uigetfile();
    case 2
        windows = winDefault;
        theFileSpec = omal_uigetfile();
    case 3
        theFileSpec = omal_uigetfile();
    case 4
         %do nothing
    otherwise
            result = {-1}; %fail
end


%read in the results table
T = readtable(theFileSpec);

%load up the interesting bits
X = T.PeakPosition;
X(:,2) = T.PeakWidth/2; %half widths


%how many windows to examine?
nw = length(windows);

%build a results array
%window size, mean, sigma, Nfound,Nfound/N
result = zeros(nw,5);

for i = 1:nw
    %make the range
    wlo = mu - windows(i)/2;
    whi = mu + windows(i)/2;
    peaksInRange = (X(:,1) >= wlo) & (X(:,1) <= whi);
    Nfound = sum(peaksInRange,'all');
    avg = mean(X(peaksInRange,1),'all');
    sd = std(X(peaksInRange,1),0,'all');
    result(i,:) = [windows(i),avg,sd,Nfound,Nfound/N];
end
   
%% save the results as csv

%get the file name parts
[fpath,fname,fext] = fileparts(theFileSpec);


% get date and time for results folder and filenames
theDateTime = datetime();
dateTimeStr = datestr(theDateTime,'_yyyymmdd_HHMMSS');

%save the results as csv
results_fn = fullfile(fpath,strcat('PeakPop_results_',fname,dateTimeStr,'.csv'));
resultsTable = array2table(result,'VariableNames',{'Window Size','Mean','Sigma','Nfound','Npercent'});
writetable(resultsTable,results_fn);

end


        
        