Documentation for these files and functions are on
https://terpconnect.umd.edu/~toh/spectrum/

and in the book
 https://terpconnect.umd.edu/~toh/spectrum/IntroToSignalProcessing2019.pdf

Tom O'Haver
December 2019
