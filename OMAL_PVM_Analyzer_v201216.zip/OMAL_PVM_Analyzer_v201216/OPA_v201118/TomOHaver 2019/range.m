function r=range(x)
r=max(x)-min(x);