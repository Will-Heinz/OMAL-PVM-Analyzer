function YXW_xtal_kinetics_peak_pop_batch()
%This function loops through all results csv files chosen by the user and
%for each file calls YXW_xtal_kinetics_peak_pop.
% YXW_xtal_kinetics_peak_pop reads in a results csv file generated from YXW_xtal_kinetics08.m
% and calculates the numbers of peaks within defined time windows of a given
% transition.

%Copyright (C) 2020, Will Heinz
% Optical Microscopy and Analysis Laboratory
% Cancer Research Technology Program
% Frederick National Laboratory for Cancer Research
% National Cancer Institute

%set the defaults
winDefault = [1 2.19482675 3 4 5 7.5 10 15 20 25 30 40 50 60 70];
N = 32400;
mu = 228.613775;

%get the filelist
[fileNames filePath] = uigetfile('*.csv','MultiSelect','on');

%loop through the list
nFiles = length(fileNames);

for i = 1:nFiles
        %get the file
        theFileSpec = fullfile(filePath,fileNames{i});
        result = YXW_xtal_kinetics_peak_pop(mu,N,winDefault, theFileSpec);
end

end